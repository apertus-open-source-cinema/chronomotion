Chronomotion
Version 0.3
------------



About
-----
This software allows the use of the Merlin/Orion/Skywatcher remote head for shooting motion controlled time lapse footage. 



Installation
------------
-) Requires Java JRE
-) Download RXTX libraries from http://rxtx.qbang.org/wiki/index.php/Download



Website
-------
http://code.google.com/p/chronomotion/



Contact
-------
Sebastian Pichelhofer - sebastian.pichelhofer (at) gmail dot com



License
-------
The Program and source code is distributed under the GNU GPL V3.
See LICENSE.txt for details


