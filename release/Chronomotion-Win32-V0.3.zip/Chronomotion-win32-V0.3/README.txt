Chronomotion 
Version 0.3
------------------------



About
-----
This software allows the use of the Merlin/Orion/Skywatcher remote head for shooting motion controlled time lapse footage. 



Website
-------
http://apertus.org/en/chronomotion



Contact
-------
Sebastian Pichelhofer - sebastian.pichelhofer (at) gmail dot com



License
-------
The Program and source code is distributed under the GNU GPL V3.
See LICENSE.txt for details


